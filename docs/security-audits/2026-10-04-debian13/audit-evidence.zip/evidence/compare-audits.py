﻿from pathlib import Path
import csv,json,collections,sys
root=Path(sys.argv[1])
out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True)
def canonical(kind,name):
    return name.removesuffix('t64') if kind=='deb' else name.lower().replace('_','-')
def inventory(role):
    d={('deb',canonical('deb',n)): {'name':n,'version':v} for n,v in [line.split('\t') for line in (root/f'{role}-packages.tsv').read_text().splitlines()]}
    for n,v in json.loads((root/f'{role}-python-packages.json').read_text()).items():
        d[('python',canonical('python',n))]={'name':n,'version':v}
    d['binary','python']={'name':'python','version':json.loads((root/f'{role}-runtime.json').read_text())['python']}
    return d
def read(role,scanner):
    raw=json.loads((root/f'{role}-{scanner}.json').read_text())
    groups=collections.defaultdict(list)
    if scanner=='grype':
        for m in raw['matches']:
            a=m['artifact'];v=m['vulnerability'];kind=a['type']
            groups[kind,canonical(kind,a['name']),v['id']].append(dict(name=a['name'],version=a['version'],severity=v['severity'],status=v['fix']['state'],fix='|'.join(v['fix']['versions']),paths='|'.join(sorted({p.get('realPath',p.get('path','')) for p in a.get('locations',[])}))))
    else:
        for result in raw['Results']:
            kind='deb' if result['Type']=='debian' else 'python'
            for v in result.get('Vulnerabilities',[]):
                groups[kind,canonical(kind,v['PkgName']),v['VulnerabilityID']].append(dict(name=v['PkgName'],version=v['InstalledVersion'],severity=v['Severity'],status=v.get('Status',''),fix=v.get('FixedVersion',''),paths=v.get('PkgPath','')))
    return groups
def values(rows,key):
    return '|'.join(sorted({r[key] for r in rows if r[key]}))
rows=[]
for scanner in ['grype','trivy']:
    before=read('baseline',scanner);after=read('candidate',scanner)
    old=inventory('baseline');new=inventory('candidate')
    for kind,name,cve in sorted(before.keys()|after.keys()):
        b=before.get((kind,name,cve),[]);a=after.get((kind,name,cve),[])
        state='retained' if b and a else 'no-longer-reported' if b else 'newly-reported'
        bi=old.get((kind,name),{});ai=new.get((kind,name),{})
        rows.append(dict(scanner=scanner,ecosystem=kind,package=name,vulnerability=cve,before_package=values(b,'name') or bi.get('name',''),after_package=values(a,'name') or ai.get('name',''),before_version=values(b,'version') or bi.get('version',''),after_version=values(a,'version') or ai.get('version',''),before_severity=values(b,'severity'),after_severity=values(a,'severity'),before_status=values(b,'status'),after_status=values(a,'status'),before_fixed_versions=values(b,'fix'),after_fixed_versions=values(a,'fix'),before_paths=values(b,'paths'),after_paths=values(a,'paths'),delta=state,follow_up=('99' if kind=='python' else '100') if a else ''))
    print(scanner,'unique package/advisory',len(before),len(after),'deltas',dict(collections.Counter(r['delta'] for r in rows if r['scanner']==scanner)))
with (out/'findings.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
print('rows',len(rows))
