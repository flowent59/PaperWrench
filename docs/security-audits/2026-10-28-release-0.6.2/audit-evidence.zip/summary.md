## Runtime image security audit

Status: **technical-error**
Exit code: 2

Occurrences: unavailable; identities: unavailable; blocking: unavailable

Expired reviewed runtime scope

| Advisory | Scanner/package/version | Severity | Decision | Expiry | Follow-up |
| --- | --- | --- | --- | --- | --- |
