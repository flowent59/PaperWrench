﻿from pathlib import Path
import subprocess,json
root=Path('issue100');repo=Path(r'C:\Users\flowe\Documents\git\paperwrench\PaperWrench-issue100')
source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();base=subprocess.check_output(['git','rev-parse','HEAD^'],cwd=repo,text=True).strip()
for role,revision in [('baseline',base),('candidate',source)]:
 log=(root/(role+'-build.log')).open('wb')
 r=subprocess.run(['docker','build','--platform','linux/amd64','--build-arg','VCS_REF='+revision,'-t','paperwrench:issue100-'+role,'--progress','plain','.'],cwd=repo,stdout=log,stderr=subprocess.STDOUT) if role=='candidate' else subprocess.run(['docker','build','--platform','linux/amd64','--build-arg','VCS_REF='+revision,'-t','paperwrench:issue100-'+role,'--progress','plain','-f','-','.'],cwd=repo,input=subprocess.check_output(['git','show',base+':Dockerfile'],cwd=repo),stdout=log,stderr=subprocess.STDOUT)
 log.close();assert r.returncode==0
 info=json.loads(subprocess.check_output(['docker','image','inspect','paperwrench:issue100-'+role]))
 assert info[0]['Config']['Labels']['org.opencontainers.image.revision']==revision
 (root/(role+'-inspect.json')).write_text(json.dumps(info,indent=2));(root/(role+'-id.txt')).write_text(info[0]['Id']+'\n');(root/(role+'-source-commit.txt')).write_text(revision+'\n')
 print(role,revision,info[0]['Id'],flush=True)
