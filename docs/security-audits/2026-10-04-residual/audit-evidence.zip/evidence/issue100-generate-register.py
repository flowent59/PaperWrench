from pathlib import Path
import json,html,re,collections,hashlib,csv,io,datetime,subprocess
root=Path('issue100');repo=Path(r'C:\Users\flowe\Documents\git\paperwrench\PaperWrench-issue100');out=repo/'docs/security-audits/2026-10-04-residual';out.mkdir(exist_ok=True)
notes=json.loads((root/'decisions-authored.json').read_text());occ=collections.defaultdict(list);g=json.loads((root/'candidate-grype.json').read_text());t=json.loads((root/'candidate-trivy.json').read_text())
for m in g['matches']:
 v=m['vulnerability'];a=m['artifact'];occ[v['id']].append(dict(scanner='grype',package=a['name'],version=a['version'],type=a['type'],severity=v['severity'],scanner_fix=v.get('fix'),scanner_paths=sorted({p['path'] for p in a.get('locations',[])})))
for result in t['Results']:
 for v in result.get('Vulnerabilities',[]):occ[v['VulnerabilityID']].append(dict(scanner='trivy',package=v['PkgName'],version=v['InstalledVersion'],type=result['Type'],severity=v['Severity'].title(),scanner_fix=dict(fixed_version=v.get('FixedVersion'),status=v.get('Status')),scanner_target=result['Target'],scanner_paths=[v['PkgPath']] if v.get('PkgPath') else []))
assert set(occ)==set(notes)
runtime=json.loads((root/'candidate-runtime-evidence.json').read_text());pkgsource={row.split('\t')[0].split(':')[0]:row.split('\t')[2] for row in runtime['packages_tsv'].splitlines()}
provider=json.loads((root/'debian-relevant.json').read_text());rank={'Critical':5,'High':4,'Medium':3,'Low':2,'Negligible':1,'Unknown':0}
records=[];counts=collections.Counter()
for c in sorted(occ):
 disposition,component,assessment,trigger=notes[c];raw=(root/'sources'/(c+'.html')).read_text(encoding='utf-8')
 links=[html.unescape(x) for x in re.findall(r'href="([^"]+)"',raw)]
 sources=['https://security-tracker.debian.org/tracker/'+c]
 # The notes section holds actual upstream references; generic navigation/search links are excluded.
 match=re.search(r'<pre>(.*?)</pre>',raw,re.S)
 if match:sources += [html.unescape(x) for x in re.findall(r'href="(https?[^\"]+)"',match.group(1))]
 aliases={c}
 for url in sources:
  aliases.update(re.findall(r'GHSA-[a-z0-9]{4}-[a-z0-9]{4}-[a-z0-9]{4}',url))
 cna=root/'sources'/(c+'.json')
 if cna.exists():
  record=json.loads(cna.read_text())['containers']['cna']
  sources += [x['url'] for x in record.get('references',[]) if 'vendor-advisory' in x.get('tags',[])]
 high=max((x['severity'] for x in occ[c]),key=lambda x:rank[x]);priority='P1' if high in ('Critical','High','Unknown') else 'P2'
 for x in occ[c]:
  x['source_package']='CPython' if x['package']=='python' else pkgsource.get(x['package'].split(':')[0])
  keys=[p for p in runtime['package_files'] if p.split(':')[0]==x['package']]
  x['installed_files']=[p for k in keys for p in runtime['package_files'][k] if Path(p).suffix=='.so' or '.so.' in p or p.startswith(('/usr/bin/','/usr/sbin/','/bin/','/sbin/'))]
  if x['package']=='python':x['installed_files']=x['scanner_paths']+list(runtime['stdlib_files'].values())
  x['installed_file_manifest']='audit/candidate-runtime-evidence.json#package_files'
 source_names={x['source_package'] for x in occ[c]};debian={p:provider[p][c].get('releases',{}).get('trixie',{}) for p in source_names if p in provider and c in provider[p]}
 item=dict(id=c,aliases=sorted(aliases),component=component,maximum_scanner_severity=high,priority=priority,disposition=disposition,assessment=assessment,
  released_trixie_fix='No released Trixie correction in provider/apt snapshot' if 'CPython' not in source_names else 'Not a Debian-installed interpreter; verify upstream 3.11 branch separately',debian_trixie_status=debian,
  owner='PaperWrench maintainer (@flowent59)',reviewed_at='2026-10-04',expires_at='2026-10-18T00:00:00Z',
  review_triggers=[trigger,'Any matched package version, architecture, application/native dependency/input path or deployment-control change','A released correction, changed upstream assessment, exploitation report or new scanner evidence','Expiry; reassess explicitly rather than automatically extending the date'],
  followup_issue=107 if 'CPython' in source_names else 108,sources=sorted(set(sources)),occurrences=sorted(occ[c],key=lambda x:(x['scanner'],x['package'],x['version'])),evidence=['audit/candidate-runtime-evidence.json','evidence/application-review.json','sources/'+c+'.html']+(['sources/'+c+'.json'] if cna.exists() else []))
 records.append(item);counts[disposition]+=1
register=dict(schema_version=1,review_pr='https://github.com/flowent59/PaperWrench/pull/106',approval='These are the proposed project dispositions reviewed through this PR; merging approves this bounded register. No scanner suppression is configured.',scope=dict(os='linux',architecture='amd64',distribution='debian:13',source_commit=(root/'candidate-source-commit.txt').read_text().strip(),image_config_id=(root/'candidate-id.txt').read_text().strip(),required_deployment_controls=['UID 10001 (non-root)','read-only root filesystem','all Linux capabilities dropped','no-new-privileges','private container /tmp tmpfs','trusted private /data and backup inputs','no privileged host binaries/services/sockets mounted','no authorized fstab entries','no installed /usr regular file with SUID or SGID']),deduplication='One record per advisory identity across scanners, grouping exact package/version occurrences. Distinct CVEs remain distinct; only explicit primary-source GHSA aliases are merged. TEMP identifiers are retained unless an upstream identity link is verified.',records=records)
(out/'dispositions.json').write_text(json.dumps(register,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
rows=['# Residual advisory decisions','', 'Reviewed 2026-10-04; proposed for approval in PR #106. Every decision expires at **2026-10-18 00:00 UTC** (02:00 Paris). Owner: PaperWrench maintainer (@flowent59). All raw findings remain visible.','', 'Exact versions, scanner paths, installed component paths, aliases, source links and change triggers are in [dispositions.json](dispositions.json). Architecture scope is **Linux amd64 only**. See [README.md](README.md) for deployment assumptions and limitations.','', '| Identifier | Max severity | Component | Disposition | Assessment | Follow-up |','| --- | --- | --- | --- | --- | --- |']
for x in records:rows.append('| ['+x['id']+'](https://security-tracker.debian.org/tracker/'+x['id']+') | '+x['maximum_scanner_severity']+' | '+x['component']+' | '+x['disposition']+' | '+x['assessment'].replace('|','\\|')+' | [#'+str(x['followup_issue'])+'](https://github.com/flowent59/PaperWrench/issues/'+str(x['followup_issue'])+') |')
(out/'decisions.md').write_text('\n'.join(rows)+'\n',encoding='utf-8')
stream=io.StringIO(newline='');writer=csv.DictWriter(stream,fieldnames=['advisory','aliases','scanner','package','version','type','severity','scanner_paths','disposition','owner','expires_at','followup_issue'],lineterminator='\n');writer.writeheader()
for x in records:
 for v in x['occurrences']:writer.writerow(dict(advisory=x['id'],aliases=';'.join(x['aliases']),scanner=v['scanner'],package=v['package'],version=v['version'],type=v['type'],severity=v['severity'],scanner_paths=';'.join(v['scanner_paths']),disposition=x['disposition'],owner=x['owner'],expires_at=x['expires_at'],followup_issue=x['followup_issue']))
(out/'findings.csv').write_text(stream.getvalue(),encoding='utf-8')
print('Coverage',len(records),'identities',sum(len(x['occurrences']) for x in records),'occurrences',dict(counts),'High identities',sum(x['maximum_scanner_severity']=='High' for x in records))
