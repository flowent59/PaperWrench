﻿from pathlib import Path
import json,hashlib,subprocess,os
root=Path('issue100');d=json.loads((root/'grype-db-latest.json').read_text());a=root/'grype-db.tar.zst'
subprocess.run(['curl.exe','-fLsS','--max-time','300','https://grype.anchore.io/databases/v6/'+d['path'],'-o',str(a)],check=True)
assert 'sha256:'+hashlib.sha256(a.read_bytes()).hexdigest()==d['checksum']
env=dict(os.environ,GRYPE_DB_CACHE_DIR=str(root.resolve()/'grype-db'),GRYPE_CHECK_FOR_APP_UPDATE='false')
subprocess.run([str(Path('issue98/grype/grype.exe').resolve()),'db','import',str(a.resolve())],env=env,check=True)
print('DB verified and imported')
