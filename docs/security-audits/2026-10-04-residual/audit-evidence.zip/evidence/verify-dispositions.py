﻿from pathlib import Path
import json,csv,hashlib,collections,datetime,sys
register_dir=Path(sys.argv[1]).resolve();extracted=Path(sys.argv[2]).resolve()
r=json.loads((register_dir/'dispositions.json').read_text());audit=extracted/'audit';scope=r['scope'];rank={'Critical':5,'High':4,'Medium':3,'Low':2,'Negligible':1,'Unknown':0}
def findings(role):
 found={}
 g=json.loads((audit/f'{role}-grype.json').read_text());t=json.loads((audit/f'{role}-trivy.json').read_text())
 for m in g['matches']:
  a=m['artifact'];v=m['vulnerability'];key=('grype',v['id'],a['name'],a['version'],'deb' if a['type']=='deb' else a['type']);assert key not in found;found[key]=v['severity']
 for result in t['Results']:
  for v in result.get('Vulnerabilities',[]):
   key=('trivy',v['VulnerabilityID'],v['PkgName'],v['InstalledVersion'],result['Type']);assert key not in found;found[key]=v['Severity'].title()
 return found,g
before,gb=findings('baseline');after,gc=findings('candidate');assert before==after;assert gb['descriptor']['db']==gc['descriptor']['db']
seen={};aliases={}
for record in r['records']:
 c=record['id'];assert c in record['aliases']
 assert record['assessment'] and record['owner'] and record['sources'] and record['review_triggers'] and record['followup_issue'] in (107,108)
 assert record['disposition'] in ('accepted-risk','mitigated','code-not-shipped','not-applicable-architecture')
 assert datetime.datetime.fromisoformat(record['expires_at'].replace('Z','+00:00')) > datetime.datetime.fromisoformat(record['reviewed_at']+'T00:00:00+00:00')
 assert record['maximum_scanner_severity']==max((v['severity'] for v in record['occurrences']),key=lambda x:rank[x])
 for alias in record['aliases']:assert alias not in aliases or aliases[alias]==c;aliases[alias]=c
 for evidence in record['evidence']:assert (extracted/evidence).is_file(),evidence
 for v in record['occurrences']:
  key=(v['scanner'],c,v['package'],v['version'],v['type']);assert key not in seen;seen[key]=v['severity'];assert v['installed_file_manifest'] and ('scanner_paths' in v)
assert seen==after;assert len(r['records'])==80;assert len(seen)==333
with (register_dir/'findings.csv').open(encoding='utf-8',newline='') as f:rows=list(csv.DictReader(f))
assert {(v['scanner'],v['advisory'],v['package'],v['version'],v['type']):v['severity'] for v in rows}==after
candidate=json.loads((audit/'candidate-runtime-evidence.json').read_text());baseline=json.loads((audit/'baseline-runtime-evidence.json').read_text());inspect=json.loads((audit/'candidate-inspect.json').read_text())[0]
assert scope['image_config_id']==inspect['Id'] and scope['source_commit']==inspect['Config']['Labels']['org.opencontainers.image.revision']
assert inspect['Architecture']=='amd64' and inspect['Os']=='linux' and candidate['architecture']=='x86_64'
assert len(baseline['privileged_files'])==11 and candidate['privileged_files']==[] and candidate['uid']==10001
assert baseline['packages_tsv']==candidate['packages_tsv'] and baseline['python_packages']==candidate['python_packages']
assert candidate['perl_modules']['Pod::Text']['importable'] is False and candidate['perl_modules']['Archive::Tar']['importable'] is False and candidate['perl_modules']['File::Temp']['importable'] is True
assert candidate['sqlite_symbols']['sqlite3changeset_apply_v3'] is False and candidate['sqlite_symbols']['sqlite3_zipfile_init'] is False
assert candidate['sqlite_symbols']['sqlite3changeset_concat'] is True and 'ENABLE_SESSION' in candidate['sqlite_compile_options']
assert 'no such function' in candidate['sqlite_zipfile_probe_error']
for name in ('getfacl','setfacl','chacl','getfattr','setfattr','bzip2recover','nscd','systemd','systemd-homed','systemd-oomd','systemd-journald','newuidmap','apt-key'):assert candidate['tools'][name] is None,name
assert all(not v for v in candidate['installer_imports'].values())
filesystem=json.loads((audit/'filesystem-scope.json').read_text());assert filesystem['node_modules']==[] and filesystem['usrmerge']=={'/bin':'/usr/bin','/sbin':'/usr/sbin'}
for line in (extracted/'reports.sha256').read_text().splitlines():
 digest,name=line.split('  ',1);assert hashlib.sha256((extracted/name).read_bytes()).hexdigest()==digest,name
print('Verified: 80 decisions cover all 333 unchanged occurrences; identities, same Grype DB, inventory, positive absence checks and privilege mitigation match raw evidence.')
