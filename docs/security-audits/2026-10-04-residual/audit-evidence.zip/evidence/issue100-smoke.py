﻿from pathlib import Path
import json,subprocess,time
r=Path('issue100');repo=Path(r'C:\Users\flowe\Documents\git\paperwrench\PaperWrench-issue100');image=(r/'candidate-id.txt').read_text().strip()
# Only a disposable fixture volume is created; no user data or credentials.
name='pw100-smoke'
subprocess.run(['docker','run','-d','--name',name,'--read-only','--tmpfs','/tmp','--cap-drop','ALL','--security-opt','no-new-privileges','-e','PAPERLESS_URL=http://paperless.invalid',image],check=True,capture_output=True)
try:
 for attempt in range(30):
  p=subprocess.run(['docker','exec',name,'python','-c',"import urllib.request; urllib.request.urlopen('http://127.0.0.1:8000/api/v1/system/health',timeout=3).read()"],capture_output=True)
  if p.returncode==0:break
  time.sleep(1)
 assert p.returncode==0,p.stderr.decode()
 for script in ('smoke_release.py','smoke_native_runtime.py'):
  p=subprocess.run(['docker','exec','-i',name,'python'],input=(repo/'scripts'/script).read_bytes(),capture_output=True);(r/(script+'.log')).write_bytes(p.stdout+p.stderr);assert p.returncode==0,p.stderr.decode()
 code=b"import sys\nfrom pathlib import Path\nfrom tempfile import TemporaryDirectory\nf={'__name__':'release_migration_fixture'}\nexec(compile(sys.stdin.read(),'test_release_migrations.py','exec'),f)\nwith TemporaryDirectory() as d:f['test_m12_backup_restore_and_idempotent_release_upgrade'](Path(d))\nprint('Populated backup, repeated migration and integrity OK')\n"
 p=subprocess.run(['docker','exec','-i',name,'python','-c',code.decode()],input=(repo/'tests/backend/unit/test_release_migrations.py').read_bytes(),capture_output=True);(r/'sqlite-restore.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0,p.stderr.decode()
 info=json.loads(subprocess.check_output(['docker','inspect',name]))[0];(r/'smoke-container-inspect.json').write_text(json.dumps(info,indent=2));assert info['HostConfig']['ReadonlyRootfs'] and info['HostConfig']['CapDrop']==['ALL'] and info['HostConfig']['SecurityOpt']==['no-new-privileges'] and info['Config']['User']=='paperwrench'
 print('Health, installed release, native TLS/credentials, populated SQLite restore and restrictions passed',flush=True)
finally:subprocess.run(['docker','rm','-fv',name],check=True,capture_output=True)
node='node:22-trixie-slim@sha256:b26b04c123d9ff8ab646ceb18b9d75a1173acf64b9a401094b906d27b29338d4'
p=subprocess.run(['docker','run','--rm','--mount','type=bind,source='+str(repo/'frontend')+',target=/build,readonly','--workdir','/build','--entrypoint','sh',node,'-c','npm audit --json; result=$?; test "$result" -le 1'],capture_output=True);assert p.returncode==0,p.stderr.decode();(r/'npm-audit.json').write_bytes(p.stdout);print('Fresh frontend audit preserved',flush=True)
