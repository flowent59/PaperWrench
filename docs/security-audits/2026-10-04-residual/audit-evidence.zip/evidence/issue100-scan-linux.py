﻿from pathlib import Path
import hashlib,subprocess,tarfile,json,datetime
root=Path('issue100').resolve();tools=root/'tools';tools.mkdir(exist_ok=True)
for name,url,sha in [('grype','https://github.com/anchore/grype/releases/download/v0.120.0/grype_0.120.0_linux_amd64.tar.gz','a5a1218dce63acdac152a6b3b5bb366e7267e36f4069848cf455543b3fa5700e'),('trivy','https://github.com/aquasecurity/trivy/releases/download/v0.75.0/trivy_0.75.0_Linux-64bit.tar.gz','c6e65abddb348e25f10549df887045629cf28cc72453cd1c63acb717316b3f3f')]:
 archive=tools/(name+'.tar.gz');subprocess.run(['curl.exe','-fsSL','--retry','2','--max-time','120',url,'-o',str(archive)],check=True);assert hashlib.sha256(archive.read_bytes()).hexdigest()==sha
 with tarfile.open(archive) as tar:(tools/name).write_bytes(tar.extractfile(name).read())
 print(name,'binary archive verified',flush=True)
base=['docker','run','--rm','--platform','linux/amd64','--user','0','--mount','type=bind,source='+str(root)+',target=/audit','--mount','type=bind,source=/var/run/docker.sock,target=/var/run/docker.sock','-e','GRYPE_DB_CACHE_DIR=/audit/grype-db','-e','GRYPE_DB_AUTO_UPDATE=false','-e','GRYPE_CHECK_FOR_APP_UPDATE=false','--entrypoint','/bin/sh','python:3.11-slim-trixie@sha256:bab1b7ef4b450c81002278d035eff85ebe394ae94df904f7a3ba14f7e16e487b','-c']
subprocess.run(base+['chmod +x /audit/tools/grype /audit/tools/trivy; /audit/tools/grype version > /audit/grype-version.txt; /audit/tools/grype db status > /audit/grype-db-status.txt; /audit/tools/trivy version --cache-dir /audit/trivy-cache > /audit/trivy-version.txt'],check=True)
(root/'started-at.txt').write_text(datetime.datetime.now(datetime.timezone.utc).isoformat())
for role in ('baseline','candidate'):
 image=(root/(role+'-id.txt')).read_text().strip()
 for name,command in [('grype',f'/audit/tools/grype docker:{image} -o json --file /audit/{role}-grype.json'),('trivy',f'/audit/tools/trivy image --quiet --cache-dir /audit/trivy-cache --skip-db-update --skip-java-db-update --offline-scan --image-src docker --scanners vuln --format json --output /audit/{role}-trivy.json {image}')]:
  with (root/(role+'-'+name+'.log')).open('wb') as log:r=subprocess.run(base+[command],stdout=log,stderr=subprocess.STDOUT)
  print(role,name,r.returncode,flush=True);assert r.returncode==0
(root/'completed-at.txt').write_text(datetime.datetime.now(datetime.timezone.utc).isoformat())
