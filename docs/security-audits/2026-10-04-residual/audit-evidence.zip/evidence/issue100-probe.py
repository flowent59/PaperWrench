﻿from pathlib import Path
import subprocess,json,hashlib,tarfile
root=Path('issue100');s=root/'sources'
for name,sha in [('zlib_1.3.dfsg+really1.3.1.orig.tar.gz','60dd315c07f616887caa029408308a018ace66e3d142726a97db164b3b8f69fb'),('zlib_1.3.dfsg+really1.3.1-1.debian.tar.xz','9ed525955ce9fb0c1b39be8ff98f73450dbfc6305a9a27e6149c8972d38a0a9e')]:
 p=s/name;subprocess.run(['curl.exe','-fsSL','--max-time','40','https://deb.debian.org/debian/pool/main/z/zlib/'+name,'-o',str(p)],check=True);assert hashlib.sha256(p.read_bytes()).hexdigest()==sha
 with tarfile.open(p) as tar:
  chosen=[m for m in tar.getmembers() if m.isfile() and (m.name.endswith('gzwrite.c') or 'debian/patches/' in m.name)]
  for m in chosen:
   data=tar.extractfile(m).read();(s/('zlib-'+Path(m.name).name)).write_bytes(data)
   assert b'gz_vacate' not in data
print('Debian zlib source/patches verified: no gz_vacate')
for role in ('baseline','candidate'):
 image=(root/(role+'-id.txt')).read_text().strip()
 r=subprocess.run(['docker','run','--rm','-i','--read-only','--tmpfs','/tmp','--cap-drop','ALL','--security-opt','no-new-privileges','--entrypoint','python',image,'-'],input=(root/'probe-runtime.py').read_bytes(),capture_output=True)
 assert r.returncode==0,r.stderr.decode();(root/(role+'-runtime-evidence.json')).write_bytes(r.stdout);d=json.loads(r.stdout)
 (root/(role+'-packages.tsv')).write_text(d['packages_tsv'])
 print(role,'setid',len(d['privileged_files']),'sqlite',d['sqlite_symbols'],'tools',d['tools'],flush=True)
 if role=='candidate':assert not d['privileged_files']
