## Runtime image security audit

Status: **technical-error**
Exit code: 2

Occurrences: unavailable; identities: unavailable; blocking: unavailable

Command &#x27;[&#x27;/tmp/paperwrench-scanners-62ukn1s3/grype&#x27;, &#x27;version&#x27;, &#x27;--format&#x27;, &#x27;json&#x27;]&#x27; returned non-zero exit status 1.

| Advisory | Scanner/package/version | Severity | Decision | Expiry | Follow-up |
| --- | --- | --- | --- | --- | --- |
