## Runtime image security audit

Status: **policy-error**
Exit code: 2

Occurrences: 594; identities: 154; blocking: 594

Approved runtime/deployment scope cannot be verified; revalidation required

| Advisory | Scanner/package/version | Severity | Decision | Expiry | Follow-up |
| --- | --- | --- | --- | --- | --- |
| CVE-2011-3389 | grype: libgnutls30 3.7.9-2+deb12u7 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-63076 | grype: libssl3 3.0.20-1~deb12u2 | High | unreviewed finding | — | — |
| CVE-2026-63076 | grype: openssl 3.0.20-1~deb12u2 | High | unreviewed finding | — | — |
| CVE-2025-13151 | grype: libtasn1-6 4.19.0-2+deb12u1 | High | unreviewed finding | — | — |
| CVE-2026-63072 | grype: libssl3 3.0.20-1~deb12u2 | High | unreviewed finding | — | — |
| CVE-2026-63072 | grype: openssl 3.0.20-1~deb12u2 | High | unreviewed finding | — | — |
| CVE-2026-5450 | grype: libc-bin 2.36-9+deb12u14 | Critical | unreviewed finding | — | — |
| CVE-2026-5450 | grype: libc6 2.36-9+deb12u14 | Critical | unreviewed finding | — | — |
| CVE-2023-50495 | grype: libncursesw6 6.4-4 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2023-50495 | grype: libtinfo6 6.4-4 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2023-50495 | grype: ncurses-base 6.4-4 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2023-50495 | grype: ncurses-bin 6.4-4 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-82560 | grype: perl-base 5.36.0-7+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-85091 | grype: zlib1g 1:1.2.13.dfsg-1 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-54874 | grype: libssl3 3.0.20-1~deb12u2 | High | unreviewed finding | — | — |
| CVE-2026-54874 | grype: openssl 3.0.20-1~deb12u2 | High | unreviewed finding | — | — |
| CVE-2026-48959 | grype: perl-base 5.36.0-7+deb12u3 | High | unreviewed finding | — | — |
| CVE-2026-8376 | grype: perl-base 5.36.0-7+deb12u3 | Critical | unreviewed finding | — | — |
| CVE-2026-41992 | grype: gzip 1.12-1 | High | unreviewed finding | — | — |
| CVE-2026-17084 | grype: python 3.11.16 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-13221 | grype: perl-base 5.36.0-7+deb12u3 | Critical | unreviewed finding | — | — |
| CVE-2026-42496 | grype: perl-base 5.36.0-7+deb12u3 | Critical | unreviewed finding | — | — |
| CVE-2026-48962 | grype: perl-base 5.36.0-7+deb12u3 | High | unreviewed finding | — | — |
| CVE-2026-5928 | grype: libc-bin 2.36-9+deb12u14 | High | unreviewed finding | — | — |
| CVE-2026-5928 | grype: libc6 2.36-9+deb12u14 | High | unreviewed finding | — | — |
| CVE-2026-42497 | grype: perl-base 5.36.0-7+deb12u3 | High | unreviewed finding | — | — |
| CVE-2026-87910 | grype: python 3.11.16 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2025-69720 | grype: libncursesw6 6.4-4 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2025-69720 | grype: libtinfo6 6.4-4 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2025-69720 | grype: ncurses-base 6.4-4 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2025-69720 | grype: ncurses-bin 6.4-4 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-12087 | grype: perl-base 5.36.0-7+deb12u3 | Critical | unreviewed finding | — | — |
| CVE-2026-9538 | grype: perl-base 5.36.0-7+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-57433 | grype: perl-base 5.36.0-7+deb12u3 | Critical | unreviewed finding | — | — |
| CVE-2026-63074 | grype: libssl3 3.0.20-1~deb12u2 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-63074 | grype: openssl 3.0.20-1~deb12u2 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-3184 | grype: bsdutils 1:2.38.1-5+deb12u3 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-3184 | grype: libblkid1 2.38.1-5+deb12u3 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-3184 | grype: libmount1 2.38.1-5+deb12u3 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-3184 | grype: libsmartcols1 2.38.1-5+deb12u3 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-3184 | grype: libuuid1 2.38.1-5+deb12u3 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-3184 | grype: mount 2.38.1-5+deb12u3 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-3184 | grype: util-linux 2.38.1-5+deb12u3 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-3184 | grype: util-linux-extra 2.38.1-5+deb12u3 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2025-12781 | grype: python 3.11.16 | Medium | reviewed runtime/deployment scope changed | — | 107 |
| CVE-2026-84782 | grype: libssl3 3.0.20-1~deb12u2 | High | unreviewed finding | — | — |
| CVE-2026-84782 | grype: openssl 3.0.20-1~deb12u2 | High | unreviewed finding | — | — |
| CVE-2026-54411 | grype: libpam-modules 1.5.2-6+deb12u2 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-54411 | grype: libpam-modules-bin 1.5.2-6+deb12u2 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-54411 | grype: libpam-runtime 1.5.2-6+deb12u2 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-54411 | grype: libpam0g 1.5.2-6+deb12u2 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-19672 | grype: python 3.11.16 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-5435 | grype: libc-bin 2.36-9+deb12u14 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-5435 | grype: libc6 2.36-9+deb12u14 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2018-20796 | grype: libc-bin 2.36-9+deb12u14 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2018-20796 | grype: libc6 2.36-9+deb12u14 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-95619 | grype: gcc-12-base 12.2.0-14+deb12u1 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-95619 | grype: libgcc-s1 12.2.0-14+deb12u1 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-95619 | grype: libstdc++6 12.2.0-14+deb12u1 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-6019 | grype: python 3.11.16 | Medium | reviewed runtime/deployment scope changed | — | 107 |
| CVE-2026-6238 | grype: libc-bin 2.36-9+deb12u14 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-6238 | grype: libc6 2.36-9+deb12u14 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-15806 | grype: python 3.11.16 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-11822 | grype: libsqlite3-0 3.40.1-2+deb12u2 | High | unreviewed finding | — | — |
| CVE-2026-42767 | grype: libssl3 3.0.20-1~deb12u2 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-42767 | grype: openssl 3.0.20-1~deb12u2 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2025-15366 | grype: python 3.11.16 | Medium | reviewed runtime/deployment scope changed | — | 107 |
| CVE-2026-19499 | grype: libc-bin 2.36-9+deb12u14 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-19499 | grype: libc6 2.36-9+deb12u14 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-80489 | grype: libc-bin 2.36-9+deb12u14 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-80489 | grype: libc6 2.36-9+deb12u14 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-77117 | grype: libc-bin 2.36-9+deb12u14 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-77117 | grype: libc6 2.36-9+deb12u14 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-19487 | grype: perl-base 5.36.0-7+deb12u3 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| GHSA-g6cj-pr64-35w5 | grype: cryptography 49.0.0 | High | unreviewed finding | — | — |
| CVE-2025-7458 | grype: libsqlite3-0 3.40.1-2+deb12u2 | Critical | unreviewed finding | — | — |
| CVE-2026-5704 | grype: tar 1.34+dfsg-1.2+deb12u1 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2025-7709 | grype: libsqlite3-0 3.40.1-2+deb12u2 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-75803 | grype: libssl3 3.0.20-1~deb12u2 | Critical | unreviewed finding | — | — |
| CVE-2026-75803 | grype: openssl 3.0.20-1~deb12u2 | Critical | unreviewed finding | — | — |
| CVE-2026-7010 | grype: perl-base 5.36.0-7+deb12u3 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2025-15367 | grype: python 3.11.16 | Medium | reviewed runtime/deployment scope changed | — | 107 |
| CVE-2005-2541 | grype: tar 1.34+dfsg-1.2+deb12u1 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-75806 | grype: libssl3 3.0.20-1~deb12u2 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-75806 | grype: openssl 3.0.20-1~deb12u2 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-6791 | grype: libc-bin 2.36-9+deb12u14 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-6791 | grype: libc6 2.36-9+deb12u14 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-102010 | grype: gcc-12-base 12.2.0-14+deb12u1 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-102010 | grype: libgcc-s1 12.2.0-14+deb12u1 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-102010 | grype: libstdc++6 12.2.0-14+deb12u1 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-7017 | grype: perl-base 5.36.0-7+deb12u3 | High | unreviewed finding | — | — |
| CVE-2026-8674 | grype: libc-bin 2.36-9+deb12u14 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-8674 | grype: libc6 2.36-9+deb12u14 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-76642 | grype: bsdutils 1:2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-76642 | grype: libblkid1 2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-76642 | grype: libmount1 2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-76642 | grype: libsmartcols1 2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-76642 | grype: libuuid1 2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-76642 | grype: mount 2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-76642 | grype: util-linux 2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-76642 | grype: util-linux-extra 2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-57432 | grype: perl-base 5.36.0-7+deb12u3 | High | unreviewed finding | — | — |
| CVE-2026-82049 | grype: python 3.11.16 | High | unreviewed finding | — | — |
| CVE-2026-103111 | grype: libpcre2-8-0 10.42-1+deb12u1 | High | unreviewed finding | — | — |
| CVE-2019-1010022 | grype: libc-bin 2.36-9+deb12u14 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2019-1010022 | grype: libc6 2.36-9+deb12u14 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2019-1010024 | grype: libc-bin 2.36-9+deb12u14 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2019-1010024 | grype: libc6 2.36-9+deb12u14 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2019-1010023 | grype: libc-bin 2.36-9+deb12u14 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2019-1010023 | grype: libc6 2.36-9+deb12u14 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-78408 | grype: bsdutils 1:2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-78408 | grype: libblkid1 2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-78408 | grype: libmount1 2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-78408 | grype: libsmartcols1 2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-78408 | grype: libuuid1 2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-78408 | grype: mount 2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-78408 | grype: util-linux 2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-78408 | grype: util-linux-extra 2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2024-56433 | grype: login 1:4.13+dfsg1-1+deb12u2 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2024-56433 | grype: passwd 1:4.13+dfsg1-1+deb12u2 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-11824 | grype: libsqlite3-0 3.40.1-2+deb12u2 | High | unreviewed finding | — | — |
| CVE-2026-35189 | grype: libssl3 3.0.20-1~deb12u2 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-35189 | grype: openssl 3.0.20-1~deb12u2 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-15534 | grype: perl-base 5.36.0-7+deb12u3 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-15310 | grype: python 3.11.16 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2010-4756 | grype: libc-bin 2.36-9+deb12u14 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2010-4756 | grype: libc6 2.36-9+deb12u14 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2024-10041 | grype: libpam-modules 1.5.2-6+deb12u2 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2024-10041 | grype: libpam-modules-bin 1.5.2-6+deb12u2 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2024-10041 | grype: libpam-runtime 1.5.2-6+deb12u2 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2024-10041 | grype: libpam0g 1.5.2-6+deb12u2 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2016-2781 | grype: coreutils 9.1-1 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-3446 | grype: python 3.11.16 | Medium | reviewed runtime/deployment scope changed | — | 107 |
| CVE-2019-9192 | grype: libc-bin 2.36-9+deb12u14 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2019-9192 | grype: libc6 2.36-9+deb12u14 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-89092 | grype: libc-bin 2.36-9+deb12u14 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-89092 | grype: libc6 2.36-9+deb12u14 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-19542 | grype: libc-bin 2.36-9+deb12u14 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-19542 | grype: libc6 2.36-9+deb12u14 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-78410 | grype: bsdutils 1:2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-78410 | grype: libblkid1 2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-78410 | grype: libmount1 2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-78410 | grype: libsmartcols1 2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-78410 | grype: libuuid1 2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-78410 | grype: mount 2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-78410 | grype: util-linux 2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-78410 | grype: util-linux-extra 2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-75805 | grype: libssl3 3.0.20-1~deb12u2 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-75805 | grype: openssl 3.0.20-1~deb12u2 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2019-1010025 | grype: libc-bin 2.36-9+deb12u14 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2019-1010025 | grype: libc6 2.36-9+deb12u14 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-13757 | grype: libp11-kit0 0.24.1-2 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-54369 | grype: libacl1 2.3.1-3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-78409 | grype: bsdutils 1:2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-78409 | grype: libblkid1 2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-78409 | grype: libmount1 2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-78409 | grype: libsmartcols1 2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-78409 | grype: libuuid1 2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-78409 | grype: mount 2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-78409 | grype: util-linux 2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-78409 | grype: util-linux-extra 2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2018-5709 | grype: libgssapi-krb5-2 1.20.1-2+deb12u5 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2018-5709 | grype: libk5crypto3 1.20.1-2+deb12u5 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2018-5709 | grype: libkrb5-3 1.20.1-2+deb12u5 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2018-5709 | grype: libkrb5support0 1.20.1-2+deb12u5 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-54371 | grype: libattr1 1:2.5.1-4 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-27171 | grype: zlib1g 1:1.2.13.dfsg-1 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-12345 | grype: python 3.11.16 | Medium | reviewed runtime/deployment scope changed | — | 107 |
| CVE-2026-97399 | grype: libc-bin 2.36-9+deb12u14 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-97399 | grype: libc6 2.36-9+deb12u14 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2025-6141 | grype: libncursesw6 6.4-4 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2025-6141 | grype: libtinfo6 6.4-4 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2025-6141 | grype: ncurses-base 6.4-4 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2025-6141 | grype: ncurses-bin 6.4-4 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2025-30258 | grype: gpgv 2.2.40-1.1+deb12u2 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-42250 | grype: libbz2-1.0 1.0.8-5+b1 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2018-6829 | grype: libgcrypt20 1.10.1-3+deb12u1 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-54872 | grype: libssl3 3.0.20-1~deb12u2 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-54872 | grype: openssl 3.0.20-1~deb12u2 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2023-31486 | grype: perl-base 5.36.0-7+deb12u3 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-13595 | grype: bsdutils 1:2.38.1-5+deb12u3 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-13595 | grype: libblkid1 2.38.1-5+deb12u3 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-13595 | grype: libmount1 2.38.1-5+deb12u3 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-13595 | grype: libsmartcols1 2.38.1-5+deb12u3 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-13595 | grype: libuuid1 2.38.1-5+deb12u3 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-13595 | grype: mount 2.38.1-5+deb12u3 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-13595 | grype: util-linux 2.38.1-5+deb12u3 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-13595 | grype: util-linux-extra 2.38.1-5+deb12u3 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-18938 | grype: libp11-kit0 0.24.1-2 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-50812 | grype: libsqlite3-0 3.40.1-2+deb12u2 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-15059 | grype: libsystemd0 252.39-1~deb12u2 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-15059 | grype: libudev1 252.39-1~deb12u2 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-50813 | grype: libsqlite3-0 3.40.1-2+deb12u2 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-54370 | grype: libacl1 2.3.1-3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-77696 | grype: libssl3 3.0.20-1~deb12u2 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-77696 | grype: openssl 3.0.20-1~deb12u2 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2021-45346 | grype: libsqlite3-0 3.40.1-2+deb12u2 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-18374 | grype: libc-bin 2.36-9+deb12u14 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-18374 | grype: libc6 2.36-9+deb12u14 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-86805 | grype: libc-bin 2.36-9+deb12u14 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-86805 | grype: libc6 2.36-9+deb12u14 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-41991 | grype: gzip 1.12-1 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2025-15649 | grype: perl-base 5.36.0-7+deb12u3 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-18508 | grype: tar 1.34+dfsg-1.2+deb12u1 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2011-3374 | grype: apt 2.6.1 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2011-3374 | grype: libapt-pkg6.0 2.6.1 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-27456 | grype: bsdutils 1:2.38.1-5+deb12u3 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-27456 | grype: libblkid1 2.38.1-5+deb12u3 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-27456 | grype: libmount1 2.38.1-5+deb12u3 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-27456 | grype: libsmartcols1 2.38.1-5+deb12u3 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-27456 | grype: libuuid1 2.38.1-5+deb12u3 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-27456 | grype: mount 2.38.1-5+deb12u3 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-27456 | grype: util-linux 2.38.1-5+deb12u3 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-27456 | grype: util-linux-extra 2.38.1-5+deb12u3 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2024-26461 | grype: libgssapi-krb5-2 1.20.1-2+deb12u5 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2024-26461 | grype: libk5crypto3 1.20.1-2+deb12u5 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2024-26461 | grype: libkrb5-3 1.20.1-2+deb12u5 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2024-26461 | grype: libkrb5support0 1.20.1-2+deb12u5 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2024-2236 | grype: libgcrypt20 1.10.1-3+deb12u1 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2025-68972 | grype: gpgv 2.2.40-1.1+deb12u2 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2007-5686 | grype: login 1:4.13+dfsg1-1+deb12u2 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2007-5686 | grype: passwd 1:4.13+dfsg1-1+deb12u2 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2022-27943 | grype: gcc-12-base 12.2.0-14+deb12u1 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2022-27943 | grype: libgcc-s1 12.2.0-14+deb12u1 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2022-27943 | grype: libstdc++6 12.2.0-14+deb12u1 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-57062 | grype: gpgv 2.2.40-1.1+deb12u2 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-40228 | grype: libsystemd0 252.39-1~deb12u2 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-40228 | grype: libudev1 252.39-1~deb12u2 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-95818 | grype: libc-bin 2.36-9+deb12u14 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-95818 | grype: libc6 2.36-9+deb12u14 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2024-26458 | grype: libgssapi-krb5-2 1.20.1-2+deb12u5 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2024-26458 | grype: libk5crypto3 1.20.1-2+deb12u5 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2024-26458 | grype: libkrb5-3 1.20.1-2+deb12u5 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2024-26458 | grype: libkrb5support0 1.20.1-2+deb12u5 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-18477 | grype: tar 1.34+dfsg-1.2+deb12u1 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-6368 | grype: libc-bin 2.36-9+deb12u14 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-6368 | grype: libc6 2.36-9+deb12u14 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-16742 | grype: libsystemd0 252.39-1~deb12u2 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-16742 | grype: libudev1 252.39-1~deb12u2 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2011-4116 | grype: perl-base 5.36.0-7+deb12u3 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2013-4392 | grype: libsystemd0 252.39-1~deb12u2 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2013-4392 | grype: libudev1 252.39-1~deb12u2 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2025-27587 | grype: libssl3 3.0.20-1~deb12u2 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2025-27587 | grype: openssl 3.0.20-1~deb12u2 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2022-0563 | grype: bsdutils 1:2.38.1-5+deb12u3 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2022-0563 | grype: libblkid1 2.38.1-5+deb12u3 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2022-0563 | grype: libmount1 2.38.1-5+deb12u3 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2022-0563 | grype: libsmartcols1 2.38.1-5+deb12u3 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2022-0563 | grype: libuuid1 2.38.1-5+deb12u3 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2022-0563 | grype: mount 2.38.1-5+deb12u3 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2022-0563 | grype: util-linux 2.38.1-5+deb12u3 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2022-0563 | grype: util-linux-extra 2.38.1-5+deb12u3 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2023-31439 | grype: libsystemd0 252.39-1~deb12u2 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2023-31439 | grype: libudev1 252.39-1~deb12u2 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2017-18018 | grype: coreutils 9.1-1 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2023-31437 | grype: libsystemd0 252.39-1~deb12u2 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2023-31437 | grype: libudev1 252.39-1~deb12u2 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-53910 | grype: diffutils 1:3.8-4 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2023-31438 | grype: libsystemd0 252.39-1~deb12u2 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2023-31438 | grype: libudev1 252.39-1~deb12u2 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2025-70873 | grype: libsqlite3-0 3.40.1-2+deb12u2 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2022-3219 | grype: gpgv 2.2.40-1.1+deb12u2 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2025-5278 | grype: coreutils 9.1-1 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-11850 | grype: libgssapi-krb5-2 1.20.1-2+deb12u5 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-11850 | grype: libk5crypto3 1.20.1-2+deb12u5 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-11850 | grype: libkrb5-3 1.20.1-2+deb12u5 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-11850 | grype: libkrb5support0 1.20.1-2+deb12u5 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-3479 | grype: python 3.11.16 | Negligible | reviewed runtime/deployment scope changed | — | 107 |
| CVE-2025-29088 | grype: libsqlite3-0 3.40.1-2+deb12u2 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2025-14104 | grype: bsdutils 1:2.38.1-5+deb12u3 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2025-14104 | grype: libblkid1 2.38.1-5+deb12u3 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2025-14104 | grype: libmount1 2.38.1-5+deb12u3 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2025-14104 | grype: libsmartcols1 2.38.1-5+deb12u3 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2025-14104 | grype: libuuid1 2.38.1-5+deb12u3 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2025-14104 | grype: mount 2.38.1-5+deb12u3 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2025-14104 | grype: util-linux 2.38.1-5+deb12u3 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2025-14104 | grype: util-linux-extra 2.38.1-5+deb12u3 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-56392 | grype: coreutils 9.1-1 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-56391 | grype: coreutils 9.1-1 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-102474 | grype: dash 0.5.12-2 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-102473 | grype: dash 0.5.12-2 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-53613 | grype: bsdutils 1:2.38.1-5+deb12u3 | High | unreviewed finding | — | — |
| CVE-2026-53615 | grype: bsdutils 1:2.38.1-5+deb12u3 | Medium | unreviewed finding | — | — |
| CVE-2026-53613 | grype: libblkid1 2.38.1-5+deb12u3 | High | unreviewed finding | — | — |
| CVE-2026-53615 | grype: libblkid1 2.38.1-5+deb12u3 | Medium | unreviewed finding | — | — |
| CVE-2026-53613 | grype: libmount1 2.38.1-5+deb12u3 | High | unreviewed finding | — | — |
| CVE-2026-53615 | grype: libmount1 2.38.1-5+deb12u3 | Medium | unreviewed finding | — | — |
| CVE-2026-53613 | grype: libsmartcols1 2.38.1-5+deb12u3 | High | unreviewed finding | — | — |
| CVE-2026-53615 | grype: libsmartcols1 2.38.1-5+deb12u3 | Medium | unreviewed finding | — | — |
| CVE-2026-53613 | grype: libuuid1 2.38.1-5+deb12u3 | High | unreviewed finding | — | — |
| CVE-2026-53615 | grype: libuuid1 2.38.1-5+deb12u3 | Medium | unreviewed finding | — | — |
| CVE-2026-53613 | grype: mount 2.38.1-5+deb12u3 | High | unreviewed finding | — | — |
| CVE-2026-53615 | grype: mount 2.38.1-5+deb12u3 | Medium | unreviewed finding | — | — |
| CVE-2026-53613 | grype: util-linux 2.38.1-5+deb12u3 | High | unreviewed finding | — | — |
| CVE-2026-53615 | grype: util-linux 2.38.1-5+deb12u3 | Medium | unreviewed finding | — | — |
| CVE-2026-53613 | grype: util-linux-extra 2.38.1-5+deb12u3 | High | unreviewed finding | — | — |
| CVE-2026-53615 | grype: util-linux-extra 2.38.1-5+deb12u3 | Medium | unreviewed finding | — | — |
| CVE-2011-3374 | trivy: apt 2.6.1 | Low | reviewed runtime/deployment scope changed | — | 108 |
| TEMP-0841856-B18BAF | trivy: bash 5.2.15-2+b13 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-53613 | trivy: bsdutils 1:2.38.1-5+deb12u3 | High | unreviewed finding | — | — |
| CVE-2026-76642 | trivy: bsdutils 1:2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-78408 | trivy: bsdutils 1:2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-78409 | trivy: bsdutils 1:2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-78410 | trivy: bsdutils 1:2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-13595 | trivy: bsdutils 1:2.38.1-5+deb12u3 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-27456 | trivy: bsdutils 1:2.38.1-5+deb12u3 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-3184 | trivy: bsdutils 1:2.38.1-5+deb12u3 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-53615 | trivy: bsdutils 1:2.38.1-5+deb12u3 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2022-0563 | trivy: bsdutils 1:2.38.1-5+deb12u3 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2025-14104 | trivy: bsdutils 1:2.38.1-5+deb12u3 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2016-2781 | trivy: coreutils 9.1-1 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2017-18018 | trivy: coreutils 9.1-1 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2025-5278 | trivy: coreutils 9.1-1 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-56391 | trivy: coreutils 9.1-1 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-56392 | trivy: coreutils 9.1-1 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-102473 | trivy: dash 0.5.12-2 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-102474 | trivy: dash 0.5.12-2 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-53910 | trivy: diffutils 1:3.8-4 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-102010 | trivy: gcc-12-base 12.2.0-14+deb12u1 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-95619 | trivy: gcc-12-base 12.2.0-14+deb12u1 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2022-27943 | trivy: gcc-12-base 12.2.0-14+deb12u1 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2025-30258 | trivy: gpgv 2.2.40-1.1+deb12u2 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2025-68972 | trivy: gpgv 2.2.40-1.1+deb12u2 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2022-3219 | trivy: gpgv 2.2.40-1.1+deb12u2 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-57062 | trivy: gpgv 2.2.40-1.1+deb12u2 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-41992 | trivy: gzip 1.12-1 | High | unreviewed finding | — | — |
| CVE-2026-41991 | trivy: gzip 1.12-1 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-54369 | trivy: libacl1 2.3.1-3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-54370 | trivy: libacl1 2.3.1-3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2011-3374 | trivy: libapt-pkg6.0 2.6.1 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-54371 | trivy: libattr1 1:2.5.1-4 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-53613 | trivy: libblkid1 2.38.1-5+deb12u3 | High | unreviewed finding | — | — |
| CVE-2026-76642 | trivy: libblkid1 2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-78408 | trivy: libblkid1 2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-78409 | trivy: libblkid1 2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-78410 | trivy: libblkid1 2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-13595 | trivy: libblkid1 2.38.1-5+deb12u3 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-27456 | trivy: libblkid1 2.38.1-5+deb12u3 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-3184 | trivy: libblkid1 2.38.1-5+deb12u3 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-53615 | trivy: libblkid1 2.38.1-5+deb12u3 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2022-0563 | trivy: libblkid1 2.38.1-5+deb12u3 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2025-14104 | trivy: libblkid1 2.38.1-5+deb12u3 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-42250 | trivy: libbz2-1.0 1.0.8-5+b1 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-18374 | trivy: libc-bin 2.36-9+deb12u14 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-19499 | trivy: libc-bin 2.36-9+deb12u14 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-19542 | trivy: libc-bin 2.36-9+deb12u14 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-5435 | trivy: libc-bin 2.36-9+deb12u14 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-5450 | trivy: libc-bin 2.36-9+deb12u14 | Critical | unreviewed finding | — | — |
| CVE-2026-5928 | trivy: libc-bin 2.36-9+deb12u14 | High | unreviewed finding | — | — |
| CVE-2026-6238 | trivy: libc-bin 2.36-9+deb12u14 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-6368 | trivy: libc-bin 2.36-9+deb12u14 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-6791 | trivy: libc-bin 2.36-9+deb12u14 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-77117 | trivy: libc-bin 2.36-9+deb12u14 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-80489 | trivy: libc-bin 2.36-9+deb12u14 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-8674 | trivy: libc-bin 2.36-9+deb12u14 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-86805 | trivy: libc-bin 2.36-9+deb12u14 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-89092 | trivy: libc-bin 2.36-9+deb12u14 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-95818 | trivy: libc-bin 2.36-9+deb12u14 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2010-4756 | trivy: libc-bin 2.36-9+deb12u14 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2018-20796 | trivy: libc-bin 2.36-9+deb12u14 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2019-1010022 | trivy: libc-bin 2.36-9+deb12u14 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2019-1010023 | trivy: libc-bin 2.36-9+deb12u14 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2019-1010024 | trivy: libc-bin 2.36-9+deb12u14 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2019-1010025 | trivy: libc-bin 2.36-9+deb12u14 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2019-9192 | trivy: libc-bin 2.36-9+deb12u14 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-97399 | trivy: libc-bin 2.36-9+deb12u14 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-18374 | trivy: libc6 2.36-9+deb12u14 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-19499 | trivy: libc6 2.36-9+deb12u14 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-19542 | trivy: libc6 2.36-9+deb12u14 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-5435 | trivy: libc6 2.36-9+deb12u14 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-5450 | trivy: libc6 2.36-9+deb12u14 | Critical | unreviewed finding | — | — |
| CVE-2026-5928 | trivy: libc6 2.36-9+deb12u14 | High | unreviewed finding | — | — |
| CVE-2026-6238 | trivy: libc6 2.36-9+deb12u14 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-6368 | trivy: libc6 2.36-9+deb12u14 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-6791 | trivy: libc6 2.36-9+deb12u14 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-77117 | trivy: libc6 2.36-9+deb12u14 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-80489 | trivy: libc6 2.36-9+deb12u14 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-8674 | trivy: libc6 2.36-9+deb12u14 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-86805 | trivy: libc6 2.36-9+deb12u14 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-89092 | trivy: libc6 2.36-9+deb12u14 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-95818 | trivy: libc6 2.36-9+deb12u14 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2010-4756 | trivy: libc6 2.36-9+deb12u14 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2018-20796 | trivy: libc6 2.36-9+deb12u14 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2019-1010022 | trivy: libc6 2.36-9+deb12u14 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2019-1010023 | trivy: libc6 2.36-9+deb12u14 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2019-1010024 | trivy: libc6 2.36-9+deb12u14 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2019-1010025 | trivy: libc6 2.36-9+deb12u14 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2019-9192 | trivy: libc6 2.36-9+deb12u14 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-97399 | trivy: libc6 2.36-9+deb12u14 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-102010 | trivy: libgcc-s1 12.2.0-14+deb12u1 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-95619 | trivy: libgcc-s1 12.2.0-14+deb12u1 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2022-27943 | trivy: libgcc-s1 12.2.0-14+deb12u1 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2018-6829 | trivy: libgcrypt20 1.10.1-3+deb12u1 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2024-2236 | trivy: libgcrypt20 1.10.1-3+deb12u1 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2011-3389 | trivy: libgnutls30 3.7.9-2+deb12u7 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2018-5709 | trivy: libgssapi-krb5-2 1.20.1-2+deb12u5 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2024-26458 | trivy: libgssapi-krb5-2 1.20.1-2+deb12u5 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2024-26461 | trivy: libgssapi-krb5-2 1.20.1-2+deb12u5 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-11850 | trivy: libgssapi-krb5-2 1.20.1-2+deb12u5 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2018-5709 | trivy: libk5crypto3 1.20.1-2+deb12u5 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2024-26458 | trivy: libk5crypto3 1.20.1-2+deb12u5 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2024-26461 | trivy: libk5crypto3 1.20.1-2+deb12u5 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-11850 | trivy: libk5crypto3 1.20.1-2+deb12u5 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2018-5709 | trivy: libkrb5-3 1.20.1-2+deb12u5 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2024-26458 | trivy: libkrb5-3 1.20.1-2+deb12u5 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2024-26461 | trivy: libkrb5-3 1.20.1-2+deb12u5 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-11850 | trivy: libkrb5-3 1.20.1-2+deb12u5 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2018-5709 | trivy: libkrb5support0 1.20.1-2+deb12u5 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2024-26458 | trivy: libkrb5support0 1.20.1-2+deb12u5 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2024-26461 | trivy: libkrb5support0 1.20.1-2+deb12u5 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-11850 | trivy: libkrb5support0 1.20.1-2+deb12u5 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-53613 | trivy: libmount1 2.38.1-5+deb12u3 | High | unreviewed finding | — | — |
| CVE-2026-76642 | trivy: libmount1 2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-78408 | trivy: libmount1 2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-78409 | trivy: libmount1 2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-78410 | trivy: libmount1 2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-13595 | trivy: libmount1 2.38.1-5+deb12u3 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-27456 | trivy: libmount1 2.38.1-5+deb12u3 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-3184 | trivy: libmount1 2.38.1-5+deb12u3 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-53615 | trivy: libmount1 2.38.1-5+deb12u3 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2022-0563 | trivy: libmount1 2.38.1-5+deb12u3 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2025-14104 | trivy: libmount1 2.38.1-5+deb12u3 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2025-69720 | trivy: libncursesw6 6.4-4 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2023-50495 | trivy: libncursesw6 6.4-4 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2025-6141 | trivy: libncursesw6 6.4-4 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-13757 | trivy: libp11-kit0 0.24.1-2 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-18938 | trivy: libp11-kit0 0.24.1-2 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2024-10041 | trivy: libpam-modules 1.5.2-6+deb12u2 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-54411 | trivy: libpam-modules 1.5.2-6+deb12u2 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2024-10041 | trivy: libpam-modules-bin 1.5.2-6+deb12u2 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-54411 | trivy: libpam-modules-bin 1.5.2-6+deb12u2 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2024-10041 | trivy: libpam-runtime 1.5.2-6+deb12u2 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-54411 | trivy: libpam-runtime 1.5.2-6+deb12u2 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2024-10041 | trivy: libpam0g 1.5.2-6+deb12u2 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-54411 | trivy: libpam0g 1.5.2-6+deb12u2 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-103111 | trivy: libpcre2-8-0 10.42-1+deb12u1 | High | unreviewed finding | — | — |
| CVE-2026-53613 | trivy: libsmartcols1 2.38.1-5+deb12u3 | High | unreviewed finding | — | — |
| CVE-2026-76642 | trivy: libsmartcols1 2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-78408 | trivy: libsmartcols1 2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-78409 | trivy: libsmartcols1 2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-78410 | trivy: libsmartcols1 2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-13595 | trivy: libsmartcols1 2.38.1-5+deb12u3 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-27456 | trivy: libsmartcols1 2.38.1-5+deb12u3 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-3184 | trivy: libsmartcols1 2.38.1-5+deb12u3 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-53615 | trivy: libsmartcols1 2.38.1-5+deb12u3 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2022-0563 | trivy: libsmartcols1 2.38.1-5+deb12u3 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2025-14104 | trivy: libsmartcols1 2.38.1-5+deb12u3 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2025-7458 | trivy: libsqlite3-0 3.40.1-2+deb12u2 | Critical | unreviewed finding | — | — |
| CVE-2026-11822 | trivy: libsqlite3-0 3.40.1-2+deb12u2 | High | unreviewed finding | — | — |
| CVE-2026-11824 | trivy: libsqlite3-0 3.40.1-2+deb12u2 | High | unreviewed finding | — | — |
| CVE-2025-7709 | trivy: libsqlite3-0 3.40.1-2+deb12u2 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-50812 | trivy: libsqlite3-0 3.40.1-2+deb12u2 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-50813 | trivy: libsqlite3-0 3.40.1-2+deb12u2 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2021-45346 | trivy: libsqlite3-0 3.40.1-2+deb12u2 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2025-29088 | trivy: libsqlite3-0 3.40.1-2+deb12u2 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2025-70873 | trivy: libsqlite3-0 3.40.1-2+deb12u2 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-84782 | trivy: libssl3 3.0.20-1~deb12u2 | High | unreviewed finding | — | — |
| CVE-2026-54872 | trivy: libssl3 3.0.20-1~deb12u2 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-63072 | trivy: libssl3 3.0.20-1~deb12u2 | High | unreviewed finding | — | — |
| CVE-2026-63076 | trivy: libssl3 3.0.20-1~deb12u2 | High | unreviewed finding | — | — |
| CVE-2026-75805 | trivy: libssl3 3.0.20-1~deb12u2 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-75806 | trivy: libssl3 3.0.20-1~deb12u2 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-77696 | trivy: libssl3 3.0.20-1~deb12u2 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2025-27587 | trivy: libssl3 3.0.20-1~deb12u2 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-35189 | trivy: libssl3 3.0.20-1~deb12u2 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-42767 | trivy: libssl3 3.0.20-1~deb12u2 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-54874 | trivy: libssl3 3.0.20-1~deb12u2 | High | unreviewed finding | — | — |
| CVE-2026-63074 | trivy: libssl3 3.0.20-1~deb12u2 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-75803 | trivy: libssl3 3.0.20-1~deb12u2 | Critical | unreviewed finding | — | — |
| CVE-2026-102010 | trivy: libstdc++6 12.2.0-14+deb12u1 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-95619 | trivy: libstdc++6 12.2.0-14+deb12u1 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2022-27943 | trivy: libstdc++6 12.2.0-14+deb12u1 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-16742 | trivy: libsystemd0 252.39-1~deb12u2 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-15059 | trivy: libsystemd0 252.39-1~deb12u2 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2013-4392 | trivy: libsystemd0 252.39-1~deb12u2 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2023-31437 | trivy: libsystemd0 252.39-1~deb12u2 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2023-31438 | trivy: libsystemd0 252.39-1~deb12u2 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2023-31439 | trivy: libsystemd0 252.39-1~deb12u2 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-40228 | trivy: libsystemd0 252.39-1~deb12u2 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2025-13151 | trivy: libtasn1-6 4.19.0-2+deb12u1 | High | unreviewed finding | — | — |
| CVE-2025-69720 | trivy: libtinfo6 6.4-4 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2023-50495 | trivy: libtinfo6 6.4-4 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2025-6141 | trivy: libtinfo6 6.4-4 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-16742 | trivy: libudev1 252.39-1~deb12u2 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-15059 | trivy: libudev1 252.39-1~deb12u2 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2013-4392 | trivy: libudev1 252.39-1~deb12u2 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2023-31437 | trivy: libudev1 252.39-1~deb12u2 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2023-31438 | trivy: libudev1 252.39-1~deb12u2 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2023-31439 | trivy: libudev1 252.39-1~deb12u2 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-40228 | trivy: libudev1 252.39-1~deb12u2 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-53613 | trivy: libuuid1 2.38.1-5+deb12u3 | High | unreviewed finding | — | — |
| CVE-2026-76642 | trivy: libuuid1 2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-78408 | trivy: libuuid1 2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-78409 | trivy: libuuid1 2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-78410 | trivy: libuuid1 2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-13595 | trivy: libuuid1 2.38.1-5+deb12u3 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-27456 | trivy: libuuid1 2.38.1-5+deb12u3 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-3184 | trivy: libuuid1 2.38.1-5+deb12u3 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-53615 | trivy: libuuid1 2.38.1-5+deb12u3 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2022-0563 | trivy: libuuid1 2.38.1-5+deb12u3 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2025-14104 | trivy: libuuid1 2.38.1-5+deb12u3 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2007-5686 | trivy: login 1:4.13+dfsg1-1+deb12u2 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2024-56433 | trivy: login 1:4.13+dfsg1-1+deb12u2 | Low | reviewed runtime/deployment scope changed | — | 108 |
| TEMP-0628843-DBAD28 | trivy: login 1:4.13+dfsg1-1+deb12u2 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-53613 | trivy: mount 2.38.1-5+deb12u3 | High | unreviewed finding | — | — |
| CVE-2026-76642 | trivy: mount 2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-78408 | trivy: mount 2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-78409 | trivy: mount 2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-78410 | trivy: mount 2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-13595 | trivy: mount 2.38.1-5+deb12u3 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-27456 | trivy: mount 2.38.1-5+deb12u3 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-3184 | trivy: mount 2.38.1-5+deb12u3 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-53615 | trivy: mount 2.38.1-5+deb12u3 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2022-0563 | trivy: mount 2.38.1-5+deb12u3 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2025-14104 | trivy: mount 2.38.1-5+deb12u3 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2025-69720 | trivy: ncurses-base 6.4-4 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2023-50495 | trivy: ncurses-base 6.4-4 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2025-6141 | trivy: ncurses-base 6.4-4 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2025-69720 | trivy: ncurses-bin 6.4-4 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2023-50495 | trivy: ncurses-bin 6.4-4 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2025-6141 | trivy: ncurses-bin 6.4-4 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-84782 | trivy: openssl 3.0.20-1~deb12u2 | High | unreviewed finding | — | — |
| CVE-2026-54872 | trivy: openssl 3.0.20-1~deb12u2 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-63072 | trivy: openssl 3.0.20-1~deb12u2 | High | unreviewed finding | — | — |
| CVE-2026-63076 | trivy: openssl 3.0.20-1~deb12u2 | High | unreviewed finding | — | — |
| CVE-2026-75805 | trivy: openssl 3.0.20-1~deb12u2 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-75806 | trivy: openssl 3.0.20-1~deb12u2 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-77696 | trivy: openssl 3.0.20-1~deb12u2 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2025-27587 | trivy: openssl 3.0.20-1~deb12u2 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-35189 | trivy: openssl 3.0.20-1~deb12u2 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-42767 | trivy: openssl 3.0.20-1~deb12u2 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-54874 | trivy: openssl 3.0.20-1~deb12u2 | High | unreviewed finding | — | — |
| CVE-2026-63074 | trivy: openssl 3.0.20-1~deb12u2 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-75803 | trivy: openssl 3.0.20-1~deb12u2 | Critical | unreviewed finding | — | — |
| CVE-2007-5686 | trivy: passwd 1:4.13+dfsg1-1+deb12u2 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2024-56433 | trivy: passwd 1:4.13+dfsg1-1+deb12u2 | Low | reviewed runtime/deployment scope changed | — | 108 |
| TEMP-0628843-DBAD28 | trivy: passwd 1:4.13+dfsg1-1+deb12u2 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-13221 | trivy: perl-base 5.36.0-7+deb12u3 | Critical | unreviewed finding | — | — |
| CVE-2026-42496 | trivy: perl-base 5.36.0-7+deb12u3 | Critical | unreviewed finding | — | — |
| CVE-2026-8376 | trivy: perl-base 5.36.0-7+deb12u3 | Critical | unreviewed finding | — | — |
| CVE-2026-42497 | trivy: perl-base 5.36.0-7+deb12u3 | High | unreviewed finding | — | — |
| CVE-2026-48962 | trivy: perl-base 5.36.0-7+deb12u3 | High | unreviewed finding | — | — |
| CVE-2026-57432 | trivy: perl-base 5.36.0-7+deb12u3 | High | unreviewed finding | — | — |
| CVE-2026-57433 | trivy: perl-base 5.36.0-7+deb12u3 | Critical | unreviewed finding | — | — |
| CVE-2026-9538 | trivy: perl-base 5.36.0-7+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2025-15649 | trivy: perl-base 5.36.0-7+deb12u3 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-12087 | trivy: perl-base 5.36.0-7+deb12u3 | Critical | unreviewed finding | — | — |
| CVE-2026-15534 | trivy: perl-base 5.36.0-7+deb12u3 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-19487 | trivy: perl-base 5.36.0-7+deb12u3 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-48959 | trivy: perl-base 5.36.0-7+deb12u3 | High | unreviewed finding | — | — |
| CVE-2026-7010 | trivy: perl-base 5.36.0-7+deb12u3 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-7017 | trivy: perl-base 5.36.0-7+deb12u3 | High | unreviewed finding | — | — |
| CVE-2011-4116 | trivy: perl-base 5.36.0-7+deb12u3 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2023-31486 | trivy: perl-base 5.36.0-7+deb12u3 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-82560 | trivy: perl-base 5.36.0-7+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| TEMP-0517018-A83CE6 | trivy: sysvinit-utils 3.06-4 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-18477 | trivy: tar 1.34+dfsg-1.2+deb12u1 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-18508 | trivy: tar 1.34+dfsg-1.2+deb12u1 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-5704 | trivy: tar 1.34+dfsg-1.2+deb12u1 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2005-2541 | trivy: tar 1.34+dfsg-1.2+deb12u1 | Low | reviewed runtime/deployment scope changed | — | 108 |
| TEMP-0290435-0B57B5 | trivy: tar 1.34+dfsg-1.2+deb12u1 | Low | reviewed runtime/deployment scope changed | — | 108 |
| DLA-4792-1 | trivy: tzdata 2026b-0+deb12u1 | Unknown | unreviewed finding | — | — |
| CVE-2026-53613 | trivy: util-linux 2.38.1-5+deb12u3 | High | unreviewed finding | — | — |
| CVE-2026-76642 | trivy: util-linux 2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-78408 | trivy: util-linux 2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-78409 | trivy: util-linux 2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-78410 | trivy: util-linux 2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-13595 | trivy: util-linux 2.38.1-5+deb12u3 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-27456 | trivy: util-linux 2.38.1-5+deb12u3 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-3184 | trivy: util-linux 2.38.1-5+deb12u3 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-53615 | trivy: util-linux 2.38.1-5+deb12u3 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2022-0563 | trivy: util-linux 2.38.1-5+deb12u3 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2025-14104 | trivy: util-linux 2.38.1-5+deb12u3 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-53613 | trivy: util-linux-extra 2.38.1-5+deb12u3 | High | unreviewed finding | — | — |
| CVE-2026-76642 | trivy: util-linux-extra 2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-78408 | trivy: util-linux-extra 2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-78409 | trivy: util-linux-extra 2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-78410 | trivy: util-linux-extra 2.38.1-5+deb12u3 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-13595 | trivy: util-linux-extra 2.38.1-5+deb12u3 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-27456 | trivy: util-linux-extra 2.38.1-5+deb12u3 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-3184 | trivy: util-linux-extra 2.38.1-5+deb12u3 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-53615 | trivy: util-linux-extra 2.38.1-5+deb12u3 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2022-0563 | trivy: util-linux-extra 2.38.1-5+deb12u3 | Low | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2025-14104 | trivy: util-linux-extra 2.38.1-5+deb12u3 | Low | initial classification required (no approved first-seen date) | — | — |
| CVE-2023-45853 | trivy: zlib1g 1:1.2.13.dfsg-1 | Critical | unreviewed finding | — | — |
| CVE-2026-27171 | trivy: zlib1g 1:1.2.13.dfsg-1 | Medium | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-85091 | trivy: zlib1g 1:1.2.13.dfsg-1 | High | reviewed runtime/deployment scope changed | — | 108 |
| CVE-2026-69247 | trivy: cryptography 49.0.0 | High | unreviewed finding | — | — |
| GHSA-6v7p-g79w-8964 | trivy: msgpack 1.1.2 | High | unreviewed finding | — | — |
| CVE-2025-47273 | trivy: setuptools 70.3.0 | High | unreviewed finding | — | — |
| CVE-2026-59890 | trivy: setuptools 70.3.0 | Medium | initial classification required (no approved first-seen date) | — | — |
| CVE-2026-97687 | trivy: urllib3 2.7.0 | High | unreviewed finding | — | — |
| CVE-2026-97689 | trivy: urllib3 2.7.0 | High | unreviewed finding | — | — |
| CVE-2026-97688 | trivy: urllib3 2.7.0 | Medium | initial classification required (no approved first-seen date) | — | — |
