"""Reproduce the release review from raw Actions artifacts; this is not a CI gate."""

import argparse
import hashlib
import json
import subprocess
import sys
from datetime import UTC
from datetime import datetime
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--repo', type=Path, required=True)
parser.add_argument('--baseline', type=Path, required=True)
parser.add_argument('--candidate', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
sys.path.insert(0, str(args.repo / 'scripts'))
from image_security import evaluate, normalize

BASE = '60e8277377d63edf5d9bdaa965502e0f3c0679a8'
CANDIDATE = '03e5e6d5308af1fa8b9961317891ab4c8d9fcdb1'

def blob(ref, path):
    return subprocess.check_output(['git', 'show', ref + ':' + path], cwd=args.repo)

def read(directory, name):
    return json.loads((directory / (name + '.json')).read_bytes())

def write(name, value):
    (args.output / name).write_bytes((json.dumps(value, indent=2, sort_keys=True) + '\n').encode())

args.output.mkdir(parents=True, exist_ok=True)
changed = subprocess.check_output(['git', 'diff', '--name-only', BASE, CANDIDATE], cwd=args.repo).decode().splitlines()
expected = ['.env.example', '.release-please-manifest.json', 'CHANGELOG.md',
            'backend/pyproject.toml', 'backend/src/paperwrench/__init__.py',
            'docker-compose.paperless.yml', 'docker-compose.yml',
            'frontend/package-lock.json', 'frontend/package.json']
assert changed == expected, changed
for path in expected:
    before, after = blob(BASE, path), blob(CANDIDATE, path)
    if path in ('frontend/package.json', 'frontend/package-lock.json', '.release-please-manifest.json'):
        old, new = json.loads(before), json.loads(after)
        if path == '.release-please-manifest.json':
            assert old['.'] == '0.6.0'; old['.'] = '0.6.1'
        else:
            assert old['version'] == '0.6.0'; old['version'] = '0.6.1'
            if path.endswith('package-lock.json'):
                assert old['packages']['']['version'] == '0.6.0'
                old['packages']['']['version'] = '0.6.1'
        assert old == new, path
    elif path == 'CHANGELOG.md':
        assert after.endswith(before.split(b'\n', 2)[2])
    else:
        assert before.replace(b'0.6.0', b'0.6.1') == after, path

metadata = [read(folder, 'metadata') for folder in (args.baseline, args.candidate)]
b, c = metadata
assert b['grype_db']['checksum'] == c['grype_db']['checksum']
assert b['trivy_db']['UpdatedAt'] == c['trivy_db']['UpdatedAt']
assert b['trivy_db']['SHA256'] == c['trivy_db']['SHA256']
for ref, item in ((BASE, b), (CANDIDATE, c)):
    tree = subprocess.check_output(['git', 'ls-tree', '-r', ref, '--', 'Dockerfile', '.dockerignore', 'docker-compose.yml', 'backend', 'frontend'], cwd=args.repo)
    assert hashlib.sha256(tree).hexdigest() == item['runtime_tree_sha256']
bp, cp = b['probe'], c['probe']
assert bp['packages_tsv'] == cp['packages_tsv']
assert bp['package_files'] == cp['package_files']
python_changes = {name: {'before': bp['python_packages'].get(name), 'after': cp['python_packages'].get(name)}
                  for name in sorted(set(bp['python_packages']) | set(cp['python_packages']))
                  if bp['python_packages'].get(name) != cp['python_packages'].get(name)}
assert python_changes == {'paperwrench': {'before': '0.6.0', 'after': '0.6.1'}}
native = ['architecture', 'uid', 'debian', 'python', 'libc', 'sqlite', 'openssl', 'zlib',
          'privileged_files', 'perl_modules', 'perl_ivsize', 'fstab', 'subuid', 'subgid',
          'login_defs', 'tools', 'sqlite_compile_options', 'sqlite_symbols',
          'sqlite_zipfile_probe_error', 'installer_imports', 'loaded_libraries',
          'stdlib_files', 'usrmerge', 'node_modules']
for key in native:
    assert bp[key] == cp[key], key
for key in ['ReadonlyRootfs', 'CapDrop', 'SecurityOpt', 'Tmpfs', 'NetworkMode']:
    assert b['container']['HostConfig'][key] == c['container']['HostConfig'][key], key

reports = [(read(folder, 'grype'), read(folder, 'trivy')) for folder in (args.baseline, args.candidate)]
signatures = [sorted(json.dumps(finding.__dict__, sort_keys=True) for finding in normalize(*pair))
              for pair in reports]
assert signatures[0] == signatures[1]
assert len(signatures[0]) == 333
registry = read(args.candidate, 'approved-dispositions')
assert registry == read(args.baseline, 'approved-dispositions')
policy = json.loads((args.repo / '.security/reviewed-runtime.json').read_bytes())
raw_registry = blob(BASE, policy['registry_path'])
assert hashlib.sha256(raw_registry).hexdigest() == policy['registry_sha256']
(args.output / 'approved-registry-blob.json').write_bytes(raw_registry)
(args.output / 'proposed-policy.json').write_bytes((json.dumps(policy, indent=2, sort_keys=True) + '\n').encode())
verdict = evaluate(*reports[1], c, registry, policy, datetime.now(UTC))
assert verdict['exit_code'] == 0 and verdict['occurrences'] == 333
write('review-preview.json', {'authoritative': False, 'purpose': 'review proposed scope before approval', 'verdict': verdict})
write('comparison.json', {
    'baseline_source': BASE, 'candidate_source': CANDIDATE, 'changed_files': changed,
    'baseline_runtime_tree_sha256': b['runtime_tree_sha256'],
    'candidate_runtime_tree_sha256': c['runtime_tree_sha256'],
    'baseline_image_id': b['image']['Id'], 'candidate_image_id': c['image']['Id'],
    'same_trivy_db_sha256': b['trivy_db']['SHA256'],
    'same_grype_db_checksum': b['grype_db']['checksum'], 'same_trivy_updated_at': b['trivy_db']['UpdatedAt'],
    'debian_inventory_identical': True, 'package_file_manifests_identical': True,
    'python_inventory_changes': python_changes, 'native_checks_identical': native,
    'deployment_controls_identical': True, 'findings_identical': True, 'occurrences_per_image': 333,
    'decision_registry_unchanged': True, 'registry_sha256': policy['registry_sha256'],
    'expires_at': '2026-10-18T00:00:00Z', 'evaluated_at': datetime.now(UTC).isoformat(),
})
print('Review comparison passed: same DBs, 333 identical occurrences; only paperwrench 0.6.0 -> 0.6.1')
